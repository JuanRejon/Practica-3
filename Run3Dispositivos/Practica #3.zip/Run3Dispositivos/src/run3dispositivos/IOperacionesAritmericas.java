/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package run3dispositivos;

/**
 *
 * @author Dell
 */
public interface IOperacionesAritmericas {
    
    public double Suma (double a, double b);
    public double Resta (double a, double b);
    public double Multi (double a, double b);
    public double Divis (double a, double b);
    
}
